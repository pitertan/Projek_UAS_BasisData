jQuery(document).ready(function(){
 /* use slicknav if bootstrap defult mobile nav not use */
 
 
 	jQuery(".single-partner-wraper").owlCarousel({

 		items : 4,
 		itemsDesktop : [1199,4],
 		itemsDesktopSmall : [980,4],
		itemsTablet: [768,4],
		itemsTabletSmall: [600,1],
		autoPlay : true
 	 });	



 /***************** Smooth Scrolling ******************/



 /***************** jquery scrool spy ******************/



 /***************** prallax with scrolly ******************/

  	jQuery('.parallax_bg').scrolly({bgParallax: true});

 /***************** wow animation activation ******************/

 	new WOW().init();

 /***************** bootstrap mobile menu coustomized ******************/


	$('#menu').slicknav({
		label : ""		
	});




});




jQuery(window).load(function($){
		// Sticky Header JS
		jQuery("#header-area").sticky({ topSpacing: 0 });
});